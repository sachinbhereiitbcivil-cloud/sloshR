## ----setup, include = FALSE---------------------------------------------------
knitr::opts_chunk$set(collapse = TRUE, comment = "#>", fig.width = 7,
                      fig.height = 4.5, dpi = 90)
library(sloshR)

## ----eval = FALSE-------------------------------------------------------------
#  log <- slosh_convert("C:/slosh.pkg/sloshdsp")   # all rex files
#  log[status != "ok"]                              # any failures
#  txt_dir <- "C:/slosh.pkg/sloshdsp/output/rex_txt"

## -----------------------------------------------------------------------------
txt_dir <- slosh_example_dir()
slosh_list_storms(txt_dir)

## -----------------------------------------------------------------------------
fr  <- slosh_read_frames("2099Demo_tst", txt_dir)   # every cell, every frame
tr  <- slosh_read_track("2099Demo_tst", txt_dir)    # storm centre and winds
env <- slosh_envelope(fr)                            # max surge per cell
head(env)

## ----fig.height = 5.5---------------------------------------------------------
site <- list(name = "Demo site", lat = 29.31, lon = -94.79)
slosh_plot_map(env, tr, site)

## -----------------------------------------------------------------------------
ev <- slosh_events(txt_dir, lat = site$lat, lon = site$lon, radius_km = 3)
ev[, .(storm, covers_site, peak_surge_m, peak_time_utc, duplicate_event)]
slosh_plot_peaks(ev, site$name)

## -----------------------------------------------------------------------------
ts <- rbind(
  slosh_site_series(slosh_read_frames("2098Sample_tst", txt_dir),
                    site$lat, site$lon),
  slosh_site_series(fr, site$lat, site$lon))
slosh_storm_metrics(ts, thresholds = c(0.5, 1, 2))
slosh_plot_series(ts, site$name)
slosh_footprint(env, thresholds = c(1, 2, 3))

## -----------------------------------------------------------------------------
t0 <- min(ts$time) - 86400
tide <- data.frame(time = t0 + seq(0, 3 * 86400, by = 600))
tide$level <- 0.4 * cos(2 * pi * as.numeric(tide$time - t0) / (12.42 * 3600))
slosh_tide_timing(ts, tide)

pk <- ts[storm == "2099Demo_tst"][which.max(surge_m), time]
rain <- data.frame(time = pk + seq(-48, 48) * 3600)
rain$value <- 40 * exp(-((seq(-48, 48) - 10) / 6)^2)
slosh_driver_lag(ts[storm == "2099Demo_tst"], rain)

## -----------------------------------------------------------------------------
obs <- data.frame(storm = ev$storm, obs_peak_m = ev$peak_surge_m + c(0.2, -0.1))
slosh_validate(ev, obs)

targets <- data.frame(target = c("Bay head", "Open coast"),
                      lat = c(29.36, 29.26), lon = c(-94.86, -94.74))
slosh_transfer(txt_dir, gauge = list(lat = 29.31, lon = -94.79), targets)

## ----eval = FALSE-------------------------------------------------------------
#  slosh_animate("2099Demo_tst", txt_dir, file = "demo.gif", site = site)

