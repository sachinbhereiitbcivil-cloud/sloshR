# rex_batch.tcl - part of the sloshR package
# Batch-convert SLOSH rex files to text with NOAA's halo library.
# Mirrors NOAA's own rex-to-data script in the SLOSH Display Program
# (halo_rexInquire, halo_conLoad_llxSet, halo_rex2xyzt).
#
# Usage (normally called by sloshR::slosh_convert()):
#   tclkit854.exe rex_batch.tcl <sdp_dir> <pattern> <out_dir>
#
# Copyright 2024 Sachin Bhere. Licensed under the Apache License, Version 2.0.
# Calls software developed by the National Weather Service (NWS), NOAA.

package require Tk
wm withdraw .

set sdp     [file normalize [lindex $argv 0]]
set pattern [expr {[llength $argv] > 1 ? [lindex $argv 1] : "*"}]
set outdir  [expr {[llength $argv] > 2 ? [file normalize [lindex $argv 2]] \
                                       : [file join $sdp output rex_txt]}]
set rexdir  [file join $sdp rexfiles]
set bntdir  [file join $sdp bnt]
file mkdir $outdir

lappend auto_path [file join $sdp bin]
if {[catch halo_pixmap_init] != 0} {
  package require -exact halo 8.0
  halo_pixmap_init
}

set log [open [file join $outdir log.txt] w]
puts $log "rexfile\tbasin\timax\tjmax\tframes\tstatus"

proc findRex {dir pattern} {
  set out [glob -nocomplain -types f -directory $dir "$pattern.rex" "$pattern.REX"]
  foreach sub [glob -nocomplain -types d -directory $dir *] {
    set out [concat $out [findRex $sub $pattern]]
  }
  return $out
}
set files {}
foreach f [findRex $rexdir $pattern] {
  set key [string tolower [file normalize $f]]
  if {![info exists seen($key)]} { set seen($key) 1; lappend files $f }
}
set files [lsort $files]
puts $log "# looked in: $rexdir (and subfolders), pattern: $pattern, found [llength $files] rex files"
flush $log

set n 0
foreach rex $files {
  set name [file rootname [file tail $rex]]
  set status ok
  set abrev ""; set imax ""; set jmax ""; set total ""
  if {[catch {
    set info  [halo_rexInquire $rex]
    set abrev [lindex $info 1]
    set imax  [lindex $info 2]
    set jmax  [lindex $info 3]
    set total [expr {[lindex $info 4] - 1}]
    if {[string length $abrev] == 3} {
      set type p; set let3 $abrev
    } else {
      set type [string index $abrev 0]; set let3 [string range $abrev 1 end]
    }
    switch -- $type {
      p { set dta basins.dta }
      e { set dta ebasins.dta }
      h { set dta hbasins.dta }
      default { error "unknown basin type '$type'" }
    }
    halo_conLoad_llxSet [file join $bntdir $dta] $let3 $type 0 5000 0 5000
    set stormdir [file join $outdir $name]
    file mkdir $stormdir
    halo_rex2xyzt $rex $total [file join $stormdir $name] txt
  } err]} {
    set status "ERROR: $err"
  }
  puts $log "$name\t$abrev\t$imax\t$jmax\t$total\t$status"
  flush $log
  incr n
}
puts $log "done: $n files"
close $log
exit
