Synthetic example data for sloshR (NOT real storms).
Two made-up storms, 2098Sample_tst and 2099Demo_tst, on a 25 x 25 grid near
29.3N 94.8W, written in the same text format slosh_convert() produces.
Used only for examples, tests and the vignette.
