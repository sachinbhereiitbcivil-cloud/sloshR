#' Compare SLOSH peaks with observations
#'
#' Matches modelled and observed peaks by storm and reports the error of
#' each storm and summary skill scores.
#'
#' @param sim Modelled peaks, usually \code{\link{slosh_events}}: needs
#'   \code{storm} and \code{peak_surge_m}; \code{peak_time_utc} optional.
#' @param obs Observed peaks: needs \code{storm} and \code{obs_peak_m};
#'   \code{obs_peak_time} (UTC) optional. Observed and modelled heights must
#'   share a datum (convert first if not).
#' @return A list of class \code{slosh_validation} with \code{table} (one
#'   row per matched storm: modelled and observed peak, \code{error_m}
#'   = model minus observation, and \code{timing_error_h} when times are
#'   given) and \code{summary} (\code{n}, \code{bias_m}, \code{mae_m},
#'   \code{rmse_m}, \code{r}, \code{mean_timing_error_h}).
#' @examples
#' ev  <- slosh_events(slosh_example_dir(), lat = 29.31, lon = -94.79,
#'                     verbose = FALSE)
#' obs <- data.frame(storm = ev$storm, obs_peak_m = ev$peak_surge_m + c(0.2, -0.1))
#' slosh_validate(ev, obs)
#' @export
slosh_validate <- function(sim, obs) {
  check_cols(sim, c("storm", "peak_surge_m"), "sim")
  check_cols(obs, c("storm", "obs_peak_m"), "obs")
  s <- as.data.table(sim)[!is.na(peak_surge_m)]
  if ("duplicate_event" %in% names(s)) s <- s[duplicate_event %in% FALSE]
  o <- as.data.table(obs)
  keep_s <- intersect(c("storm", "peak_surge_m", "peak_time_utc"), names(s))
  keep_o <- intersect(c("storm", "obs_peak_m", "obs_peak_time"), names(o))
  tab <- merge(s[, keep_s, with = FALSE], o[, keep_o, with = FALSE],
               by = "storm")
  tab <- tab[!is.na(obs_peak_m)]
  tab[, error_m := peak_surge_m - obs_peak_m]
  has_t <- all(c("peak_time_utc", "obs_peak_time") %in% names(tab))
  if (has_t) {
    tab[, timing_error_h := as.numeric(difftime(as_utc(peak_time_utc),
                                                as_utc(obs_peak_time),
                                                units = "hours"))]
  }
  e <- tab$error_m
  summ <- data.table(
    n = nrow(tab),
    bias_m = mean(e),
    mae_m = mean(abs(e)),
    rmse_m = sqrt(mean(e^2)),
    r = if (nrow(tab) > 2) stats::cor(tab$peak_surge_m, tab$obs_peak_m)
        else NA_real_,
    mean_timing_error_h = if (has_t) mean(tab$timing_error_h, na.rm = TRUE)
                          else NA_real_)
  structure(list(table = tab[], summary = summ), class = "slosh_validation")
}

#' @export
print.slosh_validation <- function(x, ...) {
  cat("SLOSH vs observed peaks:", x$summary$n, "storms\n")
  s <- x$summary
  cat(sprintf("  bias %.2f m | MAE %.2f m | RMSE %.2f m | r %s\n",
              s$bias_m, s$mae_m, s$rmse_m,
              ifelse(is.na(s$r), "NA", sprintf("%.2f", s$r))))
  if (!is.na(s$mean_timing_error_h)) {
    cat(sprintf("  mean timing error %.1f h (model minus observed)\n",
                s$mean_timing_error_h))
  }
  print(x$table)
  invisible(x)
}
