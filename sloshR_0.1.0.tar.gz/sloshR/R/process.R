#' Maximum surge envelope of one storm
#'
#' The highest water level each grid cell reached during the storm, and
#' when.
#'
#' @param frames Output of \code{\link{slosh_read_frames}}.
#' @return A data.table, one row per cell: \code{storm}, \code{cell},
#'   \code{lon}, \code{lat}, \code{max_surge_ft}, \code{max_surge_m},
#'   \code{time_of_max} (UTC; NA when the cell stayed dry),
#'   \code{cell_km} and \code{ds_deg} (approximate cell size in km and
#'   degrees, estimated from neighbouring cells).
#' @examples
#' fr  <- slosh_read_frames("2099Demo_tst", slosh_example_dir())
#' env <- slosh_envelope(fr)
#' env[order(-max_surge_m)][1:5]
#' @export
slosh_envelope <- function(frames) {
  check_cols(frames, c("cell", "lon", "lat", "surge_ft", "time"), "frames")
  st <- if ("storm" %in% names(frames)) frames$storm[1] else NA_character_
  env <- frames[, .(lon = lon[1], lat = lat[1],
                    max_surge_ft = safe_max(surge_ft),
                    time_of_max = if (all(is.na(surge_ft))) na_utc()
                                  else time[which.max(surge_ft)]),
                by = cell]
  env[, max_surge_m := ft_to_m(max_surge_ft)]
  setorder(env, cell)
  cs <- cell_size(env$lon, env$lat)
  env[, `:=`(storm = st, cell_km = cs$km, ds_deg = cs$deg)]
  setcolorder(env, c("storm", "cell", "lon", "lat", "max_surge_ft",
                     "max_surge_m", "time_of_max", "cell_km", "ds_deg"))
  set_utc(env, "time_of_max")
  env[]
}

#' Grid cells near a site
#'
#' @param x Frames (\code{\link{slosh_read_frames}}) or an envelope
#'   (\code{\link{slosh_envelope}}); needs \code{cell}, \code{lon},
#'   \code{lat}.
#' @param lat,lon Site latitude and longitude (decimal degrees, west
#'   negative).
#' @param radius_km Search radius in km.
#' @return A data.table of the cells within \code{radius_km}: \code{cell},
#'   \code{lon}, \code{lat}, \code{dist_km}, nearest first.
#' @examples
#' fr <- slosh_read_frames("2099Demo_tst", slosh_example_dir())
#' slosh_site_cells(fr, lat = 29.31, lon = -94.79, radius_km = 3)
#' @export
slosh_site_cells <- function(x, lat, lon, radius_km = 3) {
  check_cols(x, c("cell", "lon", "lat"), "x")
  s_lat <- lat; s_lon <- lon
  cells <- unique(as.data.table(x)[, c("cell", "lon", "lat"), with = FALSE],
                  by = "cell")
  cells[, dist_km := haversine_km(s_lat, s_lon, cells$lat, cells$lon)]
  cells[dist_km <= radius_km][order(dist_km)]
}

#' Surge time series at a site
#'
#' At each time step, the highest surge among wet cells within
#' \code{radius_km} of the site. Using several cells, not only the nearest,
#' avoids picking a cell that is dry land in the model grid.
#'
#' @inheritParams slosh_site_cells
#' @param frames Output of \code{\link{slosh_read_frames}}.
#' @return A data.table: \code{storm}, \code{frame}, \code{time} (UTC),
#'   \code{surge_m}, \code{surge_ft} (NA = all site cells dry). Zero rows if
#'   the storm's grid does not reach the site.
#' @examples
#' fr <- slosh_read_frames("2099Demo_tst", slosh_example_dir())
#' ts <- slosh_site_series(fr, lat = 29.31, lon = -94.79)
#' ts[which.max(surge_m)]
#' @export
slosh_site_series <- function(frames, lat, lon, radius_km = 3) {
  check_cols(frames, c("cell", "frame", "time", "surge_ft"), "frames")
  near <- slosh_site_cells(frames, lat, lon, radius_km)$cell
  st <- if ("storm" %in% names(frames)) frames$storm[1] else NA_character_
  if (!length(near)) {
    return(data.table(storm = character(), frame = integer(),
                      time = na_utc()[0], surge_m = numeric(),
                      surge_ft = numeric()))
  }
  ts <- frames[cell %in% near, .(surge_ft = safe_max(surge_ft)),
               by = .(frame, time)]
  ts[, `:=`(storm = st, surge_m = ft_to_m(surge_ft))]
  setcolorder(ts, c("storm", "frame", "time", "surge_m", "surge_ft"))
  setorder(ts, frame)
  set_utc(ts, "time")
  ts[]
}

#' Event table: peak surge of every storm at a site
#'
#' Reads each converted storm, finds its surge time series at the site and
#' summarises it in one row. Storms run on a grid that does not reach the
#' site get \code{covers_site = FALSE}. The same historical storm is
#' sometimes run on more than one grid or bathymetry (e.g. \code{1900gl2}
#' and \code{1900gls-asof1900}); repeats are flagged in
#' \code{duplicate_event} so each storm counts once.
#'
#' @inheritParams slosh_site_series
#' @param txt_dir Folder written by \code{\link{slosh_convert}}.
#' @param storms Optional character vector of storm folders; default all.
#' @param save_dir Optional folder; if given, each storm's envelope, track
#'   and site series are written there as CSV, plus the event table.
#' @param site_name Label used in the saved event-table file name.
#' @param verbose Print progress.
#' @return A data.table, one row per storm: \code{storm}, \code{year},
#'   \code{name}, \code{basin}, \code{start_utc}, \code{end_utc},
#'   \code{covers_site}, \code{n_site_cells}, \code{peak_surge_m},
#'   \code{peak_surge_ft}, \code{peak_time_utc},
#'   \code{storm_vmax_mph_10min}, \code{event} and \code{duplicate_event}.
#' @examples
#' ev <- slosh_events(slosh_example_dir(), lat = 29.31, lon = -94.79)
#' ev
#' @export
slosh_events <- function(txt_dir, lat, lon, radius_km = 3, storms = NULL,
                         save_dir = NULL, site_name = "site",
                         verbose = TRUE) {
  if (is.null(storms)) storms <- slosh_list_storms(txt_dir)$storm
  if (!length(storms)) stop("No converted storms in ", txt_dir, call. = FALSE)
  if (!is.null(save_dir)) dir.create(save_dir, showWarnings = FALSE,
                                     recursive = TRUE)
  rows <- lapply(storms, function(s) {
    if (verbose) message("  ", s)
    tryCatch({
      fr <- slosh_read_frames(s, txt_dir)
      tr <- slosh_read_track(s, txt_dir)
      ts <- slosh_site_series(fr, lat, lon, radius_km)
      n_near <- nrow(slosh_site_cells(fr[frame == min(frame)], lat, lon,
                                      radius_km))
      if (!is.null(save_dir)) {
        fwrite(slosh_envelope(fr), file.path(save_dir, paste0(s, "_envelope.csv")))
        if (nrow(tr)) fwrite(tr, file.path(save_dir, paste0(s, "_track.csv")))
        if (nrow(ts)) fwrite(ts, file.path(save_dir,
                                           paste0(s, "_site_timeseries.csv")))
      }
      pk <- if (nrow(ts) && any(!is.na(ts$surge_m))) ts[which.max(surge_m)]
            else NULL
      cbind(parse_storm_name(s), data.table(
        start_utc = min(fr$time), end_utc = max(fr$time),
        covers_site = n_near > 0, n_site_cells = n_near,
        peak_surge_m  = if (is.null(pk)) NA_real_ else round(pk$surge_m, 3),
        peak_surge_ft = if (is.null(pk)) NA_real_ else pk$surge_ft,
        peak_time_utc = if (is.null(pk)) na_utc() else pk$time,
        storm_vmax_mph_10min = if (nrow(tr)) safe_max(tr$vmax_mph_10min)
                               else NA_real_))
    }, error = function(e) {
      warning("Skipping ", s, ": ", conditionMessage(e), call. = FALSE)
      NULL
    })
  })
  ev <- rbindlist(rows, fill = TRUE)
  set_utc(ev, c("start_utc", "end_utc", "peak_time_utc"))
  setorder(ev, start_utc)
  ev[, event := paste(year, ifelse(is.na(name), "", name))]
  ev[, duplicate_event := FALSE]
  ev[covers_site == TRUE, duplicate_event := duplicated(event)]
  if (!is.null(save_dir)) {
    fwrite(ev, file.path(save_dir, paste0("slosh_events_",
                                          gsub("\\W+", "_", site_name), ".csv")))
  }
  if (verbose) {
    message(sprintf("%d storms; %d cover the site; %d unique events at the site.",
                    nrow(ev), sum(ev$covers_site),
                    sum(ev$covers_site & !ev$duplicate_event)))
  }
  ev[]
}
