#' Timing of the surge peak against the astronomical tide
#'
#' For each storm, finds the high tide nearest the surge peak, the lag
#' between them and the tide level at the moment of the peak. A storm that
#' peaks near high tide produces a higher total water level.
#'
#' @param series Site time series (\code{\link{slosh_site_series}}), one or
#'   several storms; needs \code{time}, \code{surge_m} (and \code{storm}).
#' @param tide Tide predictions at the same site: a data frame with
#'   \code{time} (POSIXct or text, UTC) and \code{level} (metres). For US
#'   stations these can be downloaded from NOAA CO-OPS.
#' @return A data.table, one row per storm: \code{storm},
#'   \code{peak_time}, \code{peak_m}, \code{tide_at_peak_m},
#'   \code{total_at_peak_m} (surge + tide), \code{nearest_high_tide},
#'   \code{lag_to_high_tide_h} (positive = surge peak after high tide; NA
#'   when the tide series has no high water within 13 h of the peak) and
#'   \code{max_tide_12h_m} (highest tide within 12 h of the peak).
#' @examples
#' fr <- slosh_read_frames("2099Demo_tst", slosh_example_dir())
#' ts <- slosh_site_series(fr, lat = 29.31, lon = -94.79)
#' t0 <- min(ts$time) - 86400
#' tide <- data.frame(time = t0 + seq(0, 3 * 86400, by = 600))
#' tide$level <- 0.4 * cos(2 * pi * as.numeric(tide$time - t0) / (12.42 * 3600))
#' slosh_tide_timing(ts, tide)
#' @export
slosh_tide_timing <- function(series, tide) {
  check_cols(series, c("time", "surge_m"), "series")
  check_cols(tide, c("time", "level"), "tide")
  td <- as.data.table(tide)[, .(time = as_utc(time), level = as.numeric(level))]
  setorder(td, time)
  n <- nrow(td)
  is_hw <- c(FALSE, td$level[-c(1, n)] >= td$level[-c(n - 1, n)] &
                    td$level[-c(1, n)] >  td$level[-c(1, 2)], FALSE)
  hw <- td$time[is_hw]
  s <- as.data.table(series)
  if (!"storm" %in% names(s)) s[, storm := "storm"]
  out <- s[!is.na(surge_m), {
    ip <- which.max(surge_m); pt <- time[ip]
    tlev <- stats::approx(as.numeric(td$time), td$level, as.numeric(pt))$y
    hw_near <- hw[abs(as.numeric(hw) - as.numeric(pt)) <= 13 * 3600]
    near <- if (length(hw_near))
              hw_near[which.min(abs(as.numeric(hw_near) - as.numeric(pt)))]
            else na_utc()
    win <- abs(as.numeric(td$time) - as.numeric(pt)) <= 12 * 3600
    list(peak_time = pt, peak_m = surge_m[ip], tide_at_peak_m = tlev,
         total_at_peak_m = surge_m[ip] + tlev, nearest_high_tide = near,
         lag_to_high_tide_h = as.numeric(difftime(pt, near, units = "hours")),
         max_tide_12h_m = if (any(win)) max(td$level[win]) else NA_real_)
  }, by = storm]
  set_utc(out, c("peak_time", "nearest_high_tide"))
  out[]
}

#' Lag between the surge peak and another flood driver
#'
#' For compound-flood timing: compares the surge peak at a site with the
#' peak of rainfall, river flow or any other series within a window around
#' it.
#'
#' @param series Site time series (\code{\link{slosh_site_series}}), one or
#'   several storms.
#' @param driver Data frame with \code{time} (POSIXct or text, UTC) and
#'   \code{value}; optionally \code{storm} to match storms by name.
#' @param window_h Hours either side of the surge peak to search.
#' @return A data.table, one row per storm: \code{storm},
#'   \code{surge_peak_time}, \code{surge_peak_m}, \code{driver_peak_time},
#'   \code{driver_peak}, \code{lag_h} (positive = driver peaks after the
#'   surge) and \code{driver_at_surge_peak}.
#' @examples
#' fr <- slosh_read_frames("2099Demo_tst", slosh_example_dir())
#' ts <- slosh_site_series(fr, lat = 29.31, lon = -94.79)
#' pk <- ts$time[which.max(ts$surge_m)]
#' rain <- data.frame(time = pk + seq(-48, 48) * 3600)
#' rain$value <- exp(-((seq(-48, 48) - 10) / 6)^2) * 40
#' slosh_driver_lag(ts, rain)
#' @export
slosh_driver_lag <- function(series, driver, window_h = 72) {
  check_cols(series, c("time", "surge_m"), "series")
  check_cols(driver, c("time", "value"), "driver")
  dr <- as.data.table(driver)
  dr[, time := as_utc(time)]
  s <- as.data.table(series)
  if (!"storm" %in% names(s)) s[, storm := "storm"]
  out <- s[!is.na(surge_m), {
    ip <- which.max(surge_m); pt <- time[ip]; st <- .BY$storm
    d <- if ("storm" %in% names(dr)) dr[dr$storm == st] else dr
    w <- d[abs(as.numeric(d$time) - as.numeric(pt)) <= window_h * 3600 &
             !is.na(d$value)]
    if (nrow(w)) {
      jd <- which.max(w$value)
      at <- stats::approx(as.numeric(w$time), w$value, as.numeric(pt))$y
      list(surge_peak_time = pt, surge_peak_m = surge_m[ip],
           driver_peak_time = w$time[jd], driver_peak = w$value[jd],
           lag_h = as.numeric(difftime(w$time[jd], pt, units = "hours")),
           driver_at_surge_peak = at)
    } else {
      list(surge_peak_time = pt, surge_peak_m = surge_m[ip],
           driver_peak_time = na_utc(), driver_peak = NA_real_,
           lag_h = NA_real_, driver_at_surge_peak = NA_real_)
    }
  }, by = storm]
  set_utc(out, c("surge_peak_time", "driver_peak_time"))
  out[]
}
