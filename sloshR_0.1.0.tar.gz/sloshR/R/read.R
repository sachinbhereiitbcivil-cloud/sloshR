#' List converted storms
#'
#' @param txt_dir Folder written by \code{\link{slosh_convert}}.
#' @param pattern Optional glob pattern, e.g. \code{"2005*"}.
#' @return A data.table: \code{storm}, \code{year}, \code{name} (NA when the
#'   file name has none), \code{basin} and \code{n_frames}.
#' @examples
#' slosh_list_storms(slosh_example_dir())
#' @export
slosh_list_storms <- function(txt_dir, pattern = "*") {
  s <- list.dirs(txt_dir, full.names = FALSE, recursive = FALSE)
  s <- s[grepl(utils::glob2rx(pattern), s)]
  if (!length(s)) return(data.table(storm = character(), year = integer(),
                                    name = character(), basin = character(),
                                    n_frames = integer()))
  out <- parse_storm_name(s)
  out[, n_frames := vapply(storm, function(z)
    nrow(frame_files(file.path(txt_dir, z), z, "txt")), integer(1))]
  out[]
}

#' Read every surge frame of one storm
#'
#' @param storm Storm folder name, e.g. \code{"2008Ike_gl2"}.
#' @param txt_dir Folder written by \code{\link{slosh_convert}}.
#' @param frames Optional integer vector of frame numbers to read.
#' @param dry_flag Values with absolute value at or above this are treated
#'   as dry or missing (SLOSH writes 99.9). Default 99.
#' @return A long data.table, one row per cell and frame: \code{storm},
#'   \code{frame}, \code{time} (UTC), \code{cell} (row number in the file),
#'   \code{lon}, \code{lat}, \code{surge_ft} and \code{surge_m} (NA = dry).
#'   Heights are relative to the SLOSH basin's vertical datum.
#' @examples
#' fr <- slosh_read_frames("2099Demo_tst", slosh_example_dir())
#' head(fr)
#' @export
slosh_read_frames <- function(storm, txt_dir, frames = NULL, dry_flag = 99) {
  ff <- frame_files(file.path(txt_dir, storm), storm, "txt")
  if (!is.null(frames)) ff <- ff[frame %in% frames]
  if (!nrow(ff)) stop("No frames for ", storm, " in ", txt_dir, call. = FALSE)
  d <- rbindlist(lapply(seq_len(nrow(ff)), function(k) {
    x <- fread(ff$file[k], skip = 1, header = FALSE,
               col.names = c("lon", "lat", "surge_ft"))
    x[, `:=`(cell = .I, frame = ff$frame[k],
             time = parse_slosh_time(readLines(ff$file[k], n = 1)))]
  }))
  d[abs(surge_ft) >= dry_flag, surge_ft := NA_real_]
  d[, `:=`(storm = storm, surge_m = ft_to_m(surge_ft))]
  setcolorder(d, c("storm", "frame", "time", "cell", "lon", "lat",
                   "surge_ft", "surge_m"))
  set_utc(d, "time")
  d[]
}

#' Read the storm track of one storm
#'
#' @inheritParams slosh_read_frames
#' @return A data.table, one row per frame: \code{storm}, \code{frame},
#'   \code{time} (UTC), \code{lat}, \code{lon} (storm centre),
#'   \code{rmax_mi} (radius of maximum winds, statute miles) and
#'   \code{vmax_mph_10min} (maximum 10-minute wind, mph). Empty if the storm
#'   has no \code{.wnd} files.
#' @examples
#' slosh_read_track("2099Demo_tst", slosh_example_dir())
#' @export
slosh_read_track <- function(storm, txt_dir) {
  ff <- frame_files(file.path(txt_dir, storm), storm, "wnd")
  if (!nrow(ff)) return(data.table(storm = character(), frame = integer(),
                                   time = na_utc()[0], lat = numeric(),
                                   lon = numeric(), rmax_mi = numeric(),
                                   vmax_mph_10min = numeric()))
  tr <- rbindlist(lapply(seq_len(nrow(ff)), function(k) {
    x <- readLines(ff$file[k], warn = FALSE)
    kv <- strsplit(x[grepl("=", x)], "=")
    v <- suppressWarnings(stats::setNames(
      as.numeric(trimws(vapply(kv, `[`, "", 2))),
      trimws(vapply(kv, `[`, "", 1))))
    pick <- function(re) unname(v[grep(re, names(v))][1])
    data.table(storm = storm, frame = ff$frame[k],
               time = parse_slosh_time(x[1]),
               lat = pick("^lat$"), lon = pick("^lon$"),
               rmax_mi = pick("^rMax"), vmax_mph_10min = pick("^vMax"))
  }))
  set_utc(tr, "time")
  tr[]
}
