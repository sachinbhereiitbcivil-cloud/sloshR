## Internal helpers --------------------------------------------------------

## great-circle distance in km
haversine_km <- function(lat1, lon1, lat2, lon2) {
  r <- pi / 180
  a <- sin((lat2 - lat1) * r / 2)^2 +
    cos(lat1 * r) * cos(lat2 * r) * sin((lon2 - lon1) * r / 2)^2
  6371 * 2 * asin(sqrt(pmin(1, a)))
}

ft_to_m <- function(x) x * 0.3048

## "9/11/2008 23:01:21 UTC :: ..." -> POSIXct UTC
parse_slosh_time <- function(line) {
  as.POSIXct(sub("\\s*UTC.*$", "", line), format = "%m/%d/%Y %H:%M:%S",
             tz = "UTC")
}

safe_max <- function(x) if (all(is.na(x))) NA_real_ else max(x, na.rm = TRUE)

na_utc <- function() as.POSIXct(NA, tz = "UTC")

set_utc <- function(dt, cols) {
  for (col in intersect(cols, names(dt))) attr(dt[[col]], "tzone") <- "UTC"
  invisible(dt)
}

## frame files are <storm><frame#>.<ext>, e.g. 2008Ike_gl2 + 17 + .txt
frame_files <- function(storm_dir, storm, ext) {
  f <- list.files(storm_dir, pattern = paste0("\\.", ext, "$"),
                  full.names = TRUE)
  id <- suppressWarnings(as.integer(sub(paste0("\\.", ext, "$"), "",
                          substring(basename(f), nchar(storm) + 1))))
  keep <- !is.na(id)
  data.table(file = f[keep], frame = id[keep])[order(frame)]
}

## 2008Ike_gl2 -> year 2008, name Ike, basin gl2
## 1900gl2     -> year 1900, name NA,  basin gl2
parse_storm_name <- function(storm) {
  yr <- suppressWarnings(as.integer(substr(storm, 1, 4)))
  rest <- substring(storm, 5)
  has_n <- grepl("_", rest)
  data.table(storm = storm, year = yr,
             name  = ifelse(has_n, sub("_.*$", "", rest), NA_character_),
             basin = ifelse(has_n, sub("^[^_]*_", "", rest), rest))
}

## approximate size of each grid cell (km and degrees) from the distance to
## its neighbour in file order; SLOSH grids are curvilinear
cell_size <- function(lon, lat) {
  n <- length(lon)
  nxt <- c(seq_len(n)[-1], NA)
  dkm <- haversine_km(lat, lon, lat[nxt], lon[nxt])
  ddeg <- sqrt((lon[nxt] - lon)^2 + (lat[nxt] - lat)^2)
  bad <- is.na(dkm) | dkm > 5 * stats::median(dkm, na.rm = TRUE)
  dkm[bad] <- NA; ddeg[bad] <- NA
  fill <- function(v) {
    v <- data.table::nafill(v, "locf")
    data.table::nafill(v, "nocb")
  }
  list(km = fill(dkm), deg = fill(ddeg))
}

check_cols <- function(x, cols, what) {
  miss <- setdiff(cols, names(x))
  if (length(miss)) {
    stop(sprintf("`%s` is missing column(s): %s", what,
                 paste(miss, collapse = ", ")), call. = FALSE)
  }
  invisible(TRUE)
}

as_utc <- function(x) {
  if (inherits(x, "POSIXct")) { attr(x, "tzone") <- "UTC"; return(x) }
  as.POSIXct(x, tz = "UTC", tryFormats = c("%Y-%m-%dT%H:%M:%OSZ",
                                           "%Y-%m-%d %H:%M:%OS",
                                           "%Y-%m-%d %H:%M", "%Y-%m-%d"))
}
