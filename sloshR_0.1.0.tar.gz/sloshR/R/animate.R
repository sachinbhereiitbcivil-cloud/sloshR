#' Animate one storm
#'
#' Draws the surge over the SLOSH grid frame by frame, with the storm track
#' so far, the storm centre and (optionally) a site labelled with its
#' current surge, and stitches the frames into a GIF.
#'
#' @param storm Storm folder name, e.g. \code{"2008Ike_gl2"}.
#' @param txt_dir Folder written by \code{\link{slosh_convert}}.
#' @param file Output GIF path. Default \code{"<storm>.gif"} in the working
#'   directory.
#' @param site Optional \code{list(name = , lat = , lon = )}.
#' @param radius_km Radius for the site value (see
#'   \code{\link{slosh_site_series}}).
#' @param every_nth Use every n-th frame (SLOSH frames are usually 10 min
#'   apart).
#' @param fps Frames per second of the GIF.
#' @param width,height Frame size in pixels.
#' @param keep_frames Keep the PNG frames (in a folder next to the GIF).
#' @return The GIF path, invisibly. If the \pkg{gifski} package is not
#'   installed, the PNG frames are kept and their folder is returned.
#' @examples
#' \donttest{
#' if (requireNamespace("gifski", quietly = TRUE)) {
#'   f <- file.path(tempdir(), "demo.gif")
#'   slosh_animate("2099Demo_tst", slosh_example_dir(), file = f,
#'                 site = list(name = "Demo site", lat = 29.31, lon = -94.79),
#'                 every_nth = 3, width = 500, height = 450)
#' }
#' }
#' @export
slosh_animate <- function(storm, txt_dir, file = paste0(storm, ".gif"),
                          site = NULL, radius_km = 3, every_nth = 2, fps = 10,
                          width = 900, height = 820, keep_frames = FALSE) {
  fr <- slosh_read_frames(storm, txt_dir)
  tr <- slosh_read_track(storm, txt_dir)
  first <- fr[frame == min(frame)]
  cs <- cell_size(first$lon, first$lat)
  sizes <- data.table(cell = first$cell, ds_deg = cs$deg)
  xl <- range(first$lon); yl <- range(first$lat)
  top <- ceiling(max(fr$surge_m, na.rm = TRUE) * 2) / 2
  ts <- if (!is.null(site)) slosh_site_series(fr, site$lat, site$lon, radius_km)
        else NULL

  frames_all <- sort(unique(fr$frame))
  use <- frames_all[seq(1, length(frames_all), by = every_nth)]
  if (!max(frames_all) %in% use) use <- c(use, max(frames_all))

  frame_dir <- file.path(dirname(file),
                         paste0(tools::file_path_sans_ext(basename(file)),
                                "_frames"))
  dir.create(frame_dir, showWarnings = FALSE, recursive = TRUE)
  pngs <- character(length(use))

  for (i in seq_along(use)) {
    f <- use[i]
    now <- fr[frame == f & !is.na(surge_m)][sizes, on = "cell", nomatch = 0]
    t <- fr[frame == f, time[1]]
    eye <- if (nrow(tr)) tr[frame == f] else tr
    so_far <- if (nrow(tr)) tr[frame <= f] else tr
    p <- ggplot2::ggplot() +
      ggplot2::geom_tile(data = now,
                         ggplot2::aes(lon, lat, fill = surge_m,
                                      width = ds_deg * 1.5,
                                      height = ds_deg * 1.5)) +
      ggplot2::scale_fill_gradientn(colours = pal$blues, limits = c(0, top),
                                    oob = scales::squish, name = "Surge (m)")
    if (nrow(so_far) > 1) {
      p <- p + ggplot2::geom_path(data = so_far, ggplot2::aes(lon, lat),
                                  colour = pal$ink2, linewidth = 0.7)
    }
    if (nrow(eye)) {
      p <- p + ggplot2::geom_point(data = eye, ggplot2::aes(lon, lat),
                                   shape = 21, size = 5, fill = pal$surface,
                                   colour = pal$ink, stroke = 1.3)
    }
    if (!is.null(site)) {
      s_now <- ts[frame == f, surge_m]
      s_txt <- if (!length(s_now) || is.na(s_now)) "dry"
               else sprintf("%.2f m", s_now)
      p <- p +
        ggplot2::annotate("point", x = site$lon, y = site$lat, shape = 21,
                          size = 3.5, fill = pal$accent, colour = pal$surface,
                          stroke = 1) +
        ggplot2::annotate("label", x = site$lon, y = site$lat,
                          label = paste0(site$name, ": ", s_txt),
                          hjust = -0.12, vjust = -0.5, size = 3.6,
                          colour = pal$ink, fill = pal$surface)
    }
    wind <- if (nrow(eye) && !is.na(eye$vmax_mph_10min[1]))
              sprintf("   |   storm wind %.0f mph", eye$vmax_mph_10min[1]) else ""
    p <- p + ggplot2::coord_quickmap(xlim = xl, ylim = yl, expand = FALSE) +
      ggplot2::labs(title = paste("SLOSH storm surge:", storm),
                    subtitle = paste0(format(t, "%d %b %Y  %H:%M UTC"), wind),
                    x = NULL, y = NULL,
                    caption = "Open circle = storm centre. Blank = dry.") +
      theme_slosh() +
      ggplot2::theme(panel.background = ggplot2::element_rect(fill = "#f0efec",
                                                              colour = NA),
                     panel.grid = ggplot2::element_blank())
    pngs[i] <- file.path(frame_dir, sprintf("frame_%04d.png", i))
    ggplot2::ggsave(pngs[i], p, width = width / 100, height = height / 100,
                    dpi = 100)
  }

  if (!requireNamespace("gifski", quietly = TRUE)) {
    message("Install the 'gifski' package to build the GIF. PNG frames are in ",
            frame_dir)
    return(invisible(frame_dir))
  }
  gifski::gifski(pngs, gif_file = file, width = width, height = height,
                 delay = 1 / fps, progress = FALSE)
  if (!keep_frames) unlink(frame_dir, recursive = TRUE)
  message("Animation saved to ", file)
  invisible(file)
}
