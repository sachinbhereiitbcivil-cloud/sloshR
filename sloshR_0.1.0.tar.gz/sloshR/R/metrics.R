#' Storm metrics from a site time series
#'
#' Peak, timing, duration above thresholds and the fastest rate of rise,
#' for one or several storms.
#'
#' @param series Output of \code{\link{slosh_site_series}}, or several
#'   stacked with \code{rbind}; needs \code{time} and \code{surge_m}, and
#'   \code{storm} to separate storms.
#' @param thresholds Surge thresholds in metres for the duration columns.
#' @return A data.table, one row per storm: \code{storm}, \code{peak_m},
#'   \code{peak_time} (UTC), \code{step_h} (time step, hours),
#'   \code{hours_wet} (hours with any water at the site), one
#'   \code{hours_above_<t>m} column per threshold, \code{max_rise_m_per_h}
#'   and \code{rise_h} (hours from first wet step to peak).
#' @examples
#' fr <- slosh_read_frames("2099Demo_tst", slosh_example_dir())
#' ts <- slosh_site_series(fr, lat = 29.31, lon = -94.79)
#' slosh_storm_metrics(ts, thresholds = c(0.5, 1, 2))
#' @export
slosh_storm_metrics <- function(series, thresholds = c(1, 2, 3)) {
  check_cols(series, c("time", "surge_m"), "series")
  s <- as.data.table(series)
  if (!"storm" %in% names(s)) s[, storm := "storm"]
  out <- s[, {
    o <- order(time); tt <- time[o]; z <- surge_m[o]
    step <- if (length(tt) > 1) stats::median(diff(as.numeric(tt))) / 3600
            else NA_real_
    has <- any(!is.na(z))
    ip <- if (has) which.max(z) else NA_integer_
    first_wet <- if (has) which(!is.na(z))[1] else NA_integer_
    dz <- diff(z) / step
    res <- list(
      peak_m = if (has) z[ip] else NA_real_,
      peak_time = if (has) tt[ip] else na_utc(),
      step_h = step,
      hours_wet = sum(!is.na(z)) * step,
      max_rise_m_per_h = if (length(dz) && any(!is.na(dz)))
                           max(dz, na.rm = TRUE) else NA_real_,
      rise_h = if (has) as.numeric(difftime(tt[ip], tt[first_wet],
                                            units = "hours")) else NA_real_)
    for (th in thresholds) {
      res[[sprintf("hours_above_%sm", format(th))]] <-
        sum(z >= th, na.rm = TRUE) * step
    }
    res
  }, by = storm]
  set_utc(out, "peak_time")
  out[]
}

#' Flood footprint of one storm
#'
#' Number of grid cells and approximate area (km2) where the storm's
#' maximum surge reached each threshold. Cell areas are estimated from the
#' spacing to neighbouring cells, so areas are approximate.
#'
#' @param envelope Output of \code{\link{slosh_envelope}}.
#' @param thresholds Surge thresholds in metres.
#' @return A data.table, one row per threshold: \code{storm},
#'   \code{threshold_m}, \code{n_cells}, \code{area_km2}.
#' @examples
#' env <- slosh_envelope(slosh_read_frames("2099Demo_tst", slosh_example_dir()))
#' slosh_footprint(env, thresholds = c(0.5, 1, 2, 3))
#' @export
slosh_footprint <- function(envelope, thresholds = c(1, 2, 3)) {
  check_cols(envelope, c("max_surge_m", "cell_km"), "envelope")
  st <- if ("storm" %in% names(envelope)) envelope$storm[1] else NA_character_
  rbindlist(lapply(thresholds, function(th) {
    w <- !is.na(envelope$max_surge_m) & envelope$max_surge_m >= th
    data.table(storm = st, threshold_m = th, n_cells = sum(w),
               area_km2 = round(sum(envelope$cell_km[w]^2, na.rm = TRUE), 1))
  }))
}
