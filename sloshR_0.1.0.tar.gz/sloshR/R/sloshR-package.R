#' sloshR: Read, Analyse and Visualise SLOSH Storm Surge Model Runs
#'
#' Tools for historical and hypothetical storm runs ("rex" files) from the
#' National Weather Service SLOSH (Sea, Lake and Overland Surges from
#' Hurricanes) storm surge model.
#'
#' @section Workflow:
#' \enumerate{
#'   \item \code{\link{slosh_convert}}: rex files to text (Windows, needs the
#'     SLOSH Display Program).
#'   \item \code{\link{slosh_list_storms}}, \code{\link{slosh_read_frames}},
#'     \code{\link{slosh_read_track}}: read the converted storms.
#'   \item \code{\link{slosh_envelope}}, \code{\link{slosh_site_series}},
#'     \code{\link{slosh_events}}: per-cell maxima, site time series and the
#'     event table.
#'   \item \code{\link{slosh_storm_metrics}}, \code{\link{slosh_footprint}}:
#'     peak, duration, rate of rise and flooded area.
#'   \item \code{\link{slosh_tide_timing}}, \code{\link{slosh_driver_lag}}:
#'     timing against tides, rainfall or river flow.
#'   \item \code{\link{slosh_validate}}, \code{\link{slosh_transfer}}:
#'     comparison with observations and site-to-gauge ratios.
#'   \item \code{\link{slosh_plot_peaks}}, \code{\link{slosh_plot_series}},
#'     \code{\link{slosh_plot_map}}, \code{\link{slosh_plot_grids}},
#'     \code{\link{slosh_animate}}: figures and animations.
#' }
#'
#' @section Appropriate use:
#' SLOSH output is intended for hurricane planning and preparedness; NOAA
#' advises that it should not be used to support engineering analysis. The
#' NOAA rex library holds only a few storms per basin, too few on their own
#' for extreme-value frequency analysis.
#'
#' @references Jelesnianski, C. P., Chen, J. and Shaffer, W. A. (1992).
#'   SLOSH: Sea, Lake, and Overland Surges from Hurricanes. NOAA Technical
#'   Report NWS 48. \url{https://repository.library.noaa.gov/view/noaa/7235}
#' @keywords internal
"_PACKAGE"

#' @import data.table
#' @importFrom stats median quantile cor approx
#' @importFrom utils head
#' @importFrom ggplot2 .data
NULL

utils::globalVariables(c(
  ".", ".N", ".I", ":=", "cell", "frame", "time", "lon", "lat", "surge_ft",
  "surge_m", "storm", "year", "name", "basin", "max_surge_m", "max_surge_ft",
  "time_of_max", "dist_km", "cell_km", "covers_site", "peak_surge_m",
  "peak_time_utc", "duplicate_event", "event", "hours", "label", "panel",
  "n", "vmax_mph_10min", "rmax_mi", "ds_deg", "level", "value", "obs_peak_m",
  "obs_peak_time", "error_m", "timing_error_h", "ratio", "target",
  "gauge_peak_m", "target_peak_m", "start_utc", "is_dup", "n_storms",
  "site_m", "peak_surge_ft", "x", "y", ".BY", "threshold_m", "ev", "n_frames"
))
