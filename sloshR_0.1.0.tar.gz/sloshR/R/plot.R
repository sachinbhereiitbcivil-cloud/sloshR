## shared look --------------------------------------------------------------
pal <- list(ink = "#0b0b0b", ink2 = "#52514e", muted = "#898781",
            grid = "#e1e0d9", base = "#c3c2b7", surface = "#fcfcfb",
            blue = "#2a78d6", light = "#9ec5f4", accent = "#eb6834",
            critical = "#d03b3b",
            blues = c("#cde2fb", "#86b6ef", "#3987e5", "#256abf", "#184f95",
                      "#0d366b"))

theme_slosh <- function(base_size = 12) {
  ggplot2::theme_minimal(base_size = base_size) +
    ggplot2::theme(
      plot.background  = ggplot2::element_rect(fill = pal$surface, colour = NA),
      panel.grid.major = ggplot2::element_line(colour = pal$grid, linewidth = 0.3),
      panel.grid.minor = ggplot2::element_blank(),
      axis.text  = ggplot2::element_text(colour = pal$muted),
      axis.title = ggplot2::element_text(colour = pal$ink2),
      plot.title = ggplot2::element_text(colour = pal$ink, face = "bold"),
      plot.subtitle = ggplot2::element_text(colour = pal$ink2),
      plot.caption  = ggplot2::element_text(colour = pal$muted, hjust = 0),
      strip.text = ggplot2::element_text(colour = pal$ink, face = "bold",
                                         hjust = 0),
      legend.title = ggplot2::element_text(colour = pal$ink2))
}

storm_label <- function(name, year) {
  ifelse(is.na(name) | name == "", as.character(year), paste(name, year))
}

#' Plot peak surge by year
#'
#' @param events Output of \code{\link{slosh_events}}.
#' @param site_name Site name for the title.
#' @return A ggplot object.
#' @examples
#' ev <- slosh_events(slosh_example_dir(), lat = 29.31, lon = -94.79,
#'                    verbose = FALSE)
#' slosh_plot_peaks(ev, "Demo site")
#' @export
slosh_plot_peaks <- function(events, site_name = "site") {
  check_cols(events, c("year", "peak_surge_m", "covers_site"), "events")
  d <- as.data.table(events)[covers_site == TRUE & !is.na(peak_surge_m)]
  if (!"duplicate_event" %in% names(d)) d[, duplicate_event := FALSE]
  d[, label := storm_label(name, year)]
  lab <- d[, .(peak_surge_m = max(peak_surge_m), label = label[1]), by = year]
  n_u <- d[duplicate_event == FALSE, .N]
  ggplot2::ggplot(d, ggplot2::aes(year, peak_surge_m)) +
    ggplot2::geom_segment(ggplot2::aes(xend = year, y = 0,
                                       yend = peak_surge_m),
                          colour = ifelse(d$duplicate_event, pal$light, pal$blue),
                          linewidth = 0.8) +
    ggplot2::geom_point(ggplot2::aes(shape = duplicate_event), size = 3.2,
                        colour = pal$blue, fill = pal$surface, stroke = 1.2) +
    ggplot2::geom_text(data = lab, ggplot2::aes(label = label), vjust = -1.3,
                       size = 3.4, colour = pal$ink2) +
    ggplot2::scale_shape_manual(values = c(`FALSE` = 19, `TRUE` = 21),
                                labels = c(`FALSE` = "Event",
                                           `TRUE` = "Repeat run of same storm"),
                                name = NULL, drop = TRUE) +
    ggplot2::scale_y_continuous(expand = ggplot2::expansion(mult = c(0, 0.15))) +
    ggplot2::labs(title = paste("Peak SLOSH storm surge at", site_name),
                  subtitle = paste(n_u, "unique storms cover this site"),
                  x = NULL, y = "Peak surge (m above SLOSH datum)") +
    theme_slosh() +
    ggplot2::theme(legend.position = "top", legend.justification = "left")
}

#' Plot site time series, one panel per storm
#'
#' @param series Site series (\code{\link{slosh_site_series}}) for one or
#'   more storms stacked with \code{rbind}.
#' @param site_name Site name for the title.
#' @param align_peak If \code{TRUE} (default), the x axis is hours from each
#'   storm's peak; otherwise clock time (UTC).
#' @param ncol Number of panel columns.
#' @return A ggplot object.
#' @examples
#' d  <- slosh_example_dir()
#' ts <- rbind(
#'   slosh_site_series(slosh_read_frames("2098Sample_tst", d), 29.31, -94.79),
#'   slosh_site_series(slosh_read_frames("2099Demo_tst", d), 29.31, -94.79))
#' slosh_plot_series(ts, "Demo site")
#' @export
slosh_plot_series <- function(series, site_name = "site", align_peak = TRUE,
                              ncol = 2) {
  check_cols(series, c("storm", "time", "surge_m"), "series")
  d <- as.data.table(series)
  d[, hours := {
    pk <- if (any(!is.na(surge_m))) time[which.max(surge_m)] else time[1]
    as.numeric(difftime(time, pk, units = "hours"))
  }, by = storm]
  d[, panel := factor(storm, levels = unique(storm))]
  xvar <- if (align_peak) "hours" else "time"
  p <- ggplot2::ggplot(d, ggplot2::aes(.data[[xvar]], surge_m)) +
    ggplot2::geom_hline(yintercept = 0, colour = pal$base, linewidth = 0.4) +
    ggplot2::geom_line(colour = pal$blue, linewidth = 0.8, na.rm = TRUE) +
    ggplot2::facet_wrap(~ panel, ncol = ncol,
                        scales = if (align_peak) "fixed" else "free_x") +
    ggplot2::labs(title = paste("Storm surge through each storm at", site_name),
                  subtitle = "Gaps = all site cells dry",
                  x = if (align_peak) "Hours from peak" else "Time (UTC)",
                  y = "Surge (m)") +
    theme_slosh()
  if (align_peak) {
    p <- p + ggplot2::geom_vline(xintercept = 0, colour = pal$grid,
                                 linetype = "dashed")
  }
  p
}

#' Map of a storm's maximum surge
#'
#' @param envelope Output of \code{\link{slosh_envelope}}.
#' @param track Optional storm track (\code{\link{slosh_read_track}}).
#' @param site Optional \code{list(name = , lat = , lon = )} to mark.
#' @param title Plot title; default uses the storm name.
#' @return A ggplot object.
#' @examples
#' d <- slosh_example_dir()
#' env <- slosh_envelope(slosh_read_frames("2099Demo_tst", d))
#' slosh_plot_map(env, slosh_read_track("2099Demo_tst", d),
#'                site = list(name = "Demo site", lat = 29.31, lon = -94.79))
#' @export
slosh_plot_map <- function(envelope, track = NULL, site = NULL, title = NULL) {
  check_cols(envelope, c("lon", "lat", "max_surge_m", "ds_deg"), "envelope")
  e <- as.data.table(envelope)
  xl <- range(e$lon); yl <- range(e$lat)
  e <- e[!is.na(max_surge_m)]
  st <- if ("storm" %in% names(e)) e$storm[1] else ""
  p <- ggplot2::ggplot() +
    ggplot2::geom_tile(data = e, ggplot2::aes(lon, lat, fill = max_surge_m,
                                              width = ds_deg * 1.5,
                                              height = ds_deg * 1.5)) +
    ggplot2::scale_fill_gradientn(colours = pal$blues[-1],
                                  name = "Max surge (m)")
  if (!is.null(track) && nrow(track) > 1) {
    p <- p + ggplot2::geom_path(data = track, ggplot2::aes(lon, lat),
                                colour = pal$ink2, linewidth = 0.7,
                                arrow = grid::arrow(length = grid::unit(2.5, "mm")))
  }
  if (!is.null(site)) {
    p <- p +
      ggplot2::annotate("point", x = site$lon, y = site$lat, shape = 21,
                        size = 4, fill = pal$accent, colour = pal$surface,
                        stroke = 1.2) +
      ggplot2::annotate("text", x = site$lon, y = site$lat,
                        label = if (is.null(site$name)) "" else site$name,
                        hjust = -0.2, vjust = -0.6, colour = pal$ink, size = 3.6)
  }
  p + ggplot2::coord_quickmap(xlim = xl, ylim = yl) +
    ggplot2::labs(title = if (is.null(title)) paste("Maximum surge:", st)
                          else title,
                  subtitle = "Highest water each grid cell reached; blank = dry",
                  x = "Longitude", y = "Latitude") +
    theme_slosh()
}

#' Plot how many storms each SLOSH grid has
#'
#' @param events Output of \code{\link{slosh_events}} (all storms).
#' @param needed Reference line for the number of events a frequency
#'   analysis typically needs. Use \code{NULL} for none.
#' @return A ggplot object.
#' @examples
#' ev <- slosh_events(slosh_example_dir(), lat = 29.31, lon = -94.79,
#'                    verbose = FALSE)
#' slosh_plot_grids(ev)
#' @export
slosh_plot_grids <- function(events, needed = 30) {
  check_cols(events, c("basin", "year"), "events")
  d <- as.data.table(events)
  d <- unique(d[, .(basin, ev = paste(year, ifelse(is.na(name), "", name)))])
  g <- d[, .(n_storms = .N), by = basin][order(n_storms)]
  g[, basin := factor(basin, levels = basin)]
  top <- max(c(g$n_storms, needed)) * 1.08
  p <- ggplot2::ggplot(g, ggplot2::aes(n_storms, basin)) +
    ggplot2::geom_col(fill = pal$blue, width = 0.7) +
    ggplot2::geom_text(ggplot2::aes(label = n_storms), hjust = -0.4, size = 3.2,
                       colour = pal$ink2) +
    ggplot2::scale_x_continuous(expand = ggplot2::expansion(mult = c(0, 0)),
                                limits = c(0, top)) +
    ggplot2::labs(title = "Historical storms available per SLOSH grid",
                  x = "Number of storms", y = "SLOSH grid") +
    theme_slosh() +
    ggplot2::theme(panel.grid.major.y = ggplot2::element_blank())
  if (!is.null(needed)) {
    p <- p +
      ggplot2::geom_vline(xintercept = needed, colour = pal$critical,
                          linetype = "dashed") +
      ggplot2::annotate("text", x = needed, y = 0.6,
                        label = paste0("~", needed, " events"), hjust = 1.05,
                        colour = pal$critical, size = 3.2)
  }
  p
}
