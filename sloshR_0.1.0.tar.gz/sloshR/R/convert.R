#' Convert SLOSH rex files to text
#'
#' Runs NOAA's SLOSH Display Program library in batch to write every frame of
#' every rex file as text: one folder per storm, each frame as
#' \code{<storm><frame>.txt} (longitude, latitude, surge in feet) and
#' \code{<storm><frame>.wnd} (storm centre, radius of maximum winds and wind
#' speed).
#'
#' This step needs Windows and an installed SLOSH Display Program, because
#' NOAA's library is a 32-bit Windows DLL. All other sloshR functions work
#' on the converted text on any platform.
#'
#' @param sdp_dir Folder of the SLOSH Display Program, the one holding
#'   \code{bin}, \code{bnt} and \code{rexfiles}.
#' @param pattern File-name pattern (without \code{.rex}), e.g.
#'   \code{"2008Ike*"}. Default \code{"*"} converts every rex file found in
#'   \code{rexfiles} and its subfolders.
#' @param out_dir Where to write the text. Default
#'   \code{<sdp_dir>/output/rex_txt}.
#' @param tclkit Path to NOAA's Tcl interpreter. Default
#'   \code{<sdp_dir>/bin/tclkit854.exe}.
#' @return The conversion log (see \code{\link{slosh_read_log}}), invisibly.
#' @seealso \code{\link{slosh_read_log}}, \code{\link{slosh_list_storms}}
#' @examples
#' \dontrun{
#' log <- slosh_convert("C:/slosh.pkg/sloshdsp", pattern = "2008Ike*")
#' log
#' }
#' @export
slosh_convert <- function(sdp_dir, pattern = "*", out_dir = NULL,
                          tclkit = NULL) {
  if (.Platform$OS.type != "windows") {
    stop("slosh_convert() needs Windows: NOAA's SLOSH library is a Windows ",
         "DLL. Convert on Windows, then use the other functions anywhere.",
         call. = FALSE)
  }
  sdp_dir <- normalizePath(sdp_dir, winslash = "/", mustWork = TRUE)
  if (is.null(out_dir)) out_dir <- file.path(sdp_dir, "output", "rex_txt")
  dir.create(out_dir, showWarnings = FALSE, recursive = TRUE)
  out_dir <- normalizePath(out_dir, winslash = "/")
  if (is.null(tclkit)) tclkit <- file.path(sdp_dir, "bin", "tclkit854.exe")
  if (!file.exists(tclkit)) {
    stop("Cannot find NOAA's Tcl interpreter at ", tclkit, call. = FALSE)
  }
  script <- system.file("tcl", "rex_batch.tcl", package = "sloshR")
  status <- system2(tclkit, args = shQuote(c(script, sdp_dir, pattern, out_dir)),
                    wait = TRUE)
  if (!identical(as.integer(status), 0L)) {
    warning("The converter exited with status ", status, call. = FALSE)
  }
  log <- slosh_read_log(out_dir)
  n_err <- sum(log$status != "ok")
  message(sprintf("Converted %d of %d rex files to %s", nrow(log) - n_err,
                  nrow(log), out_dir))
  if (n_err) message(n_err, " failed: see the `status` column.")
  invisible(log)
}

#' Read the conversion log
#'
#' @param txt_dir Folder written by \code{\link{slosh_convert}}.
#' @return A data.table with one row per rex file: \code{rexfile},
#'   \code{basin} (NOAA basin code, prefixed \code{e} or \code{h} for
#'   elliptical or hyperbolic grids), \code{imax}, \code{jmax} (grid size),
#'   \code{frames} and \code{status} (\code{"ok"} or the error).
#' @examples
#' slosh_read_log(slosh_example_dir())
#' @export
slosh_read_log <- function(txt_dir) {
  f <- file.path(txt_dir, "log.txt")
  if (!file.exists(f)) stop("No log.txt in ", txt_dir, call. = FALSE)
  x <- readLines(f, warn = FALSE)
  x <- x[!grepl("^#|^done:", x)]
  log <- fread(text = paste(x, collapse = "\n"), sep = "\t",
               colClasses = "character")
  for (col in c("imax", "jmax", "frames")) {
    log[, (col) := suppressWarnings(as.integer(get(col)))]
  }
  log[]
}

#' Path to the example data shipped with sloshR
#'
#' Two synthetic storms (\code{2098Sample_tst}, \code{2099Demo_tst}) in the
#' same format \code{\link{slosh_convert}} writes, on a small made-up grid.
#' They exist to run the examples and tests; they are not real storms.
#'
#' @return Path to the example \code{rex_txt} folder.
#' @examples
#' slosh_list_storms(slosh_example_dir())
#' @export
slosh_example_dir <- function() {
  system.file("extdata", "rex_txt", package = "sloshR", mustWork = TRUE)
}
