#' Surge at other locations relative to a reference gauge
#'
#' For every storm whose grid covers both the gauge and a target location,
#' the ratio of the target's peak surge to the gauge's peak surge. A stable
#' ratio across storms lets a long gauge-based frequency analysis be carried
#' to locations without a gauge (a hybrid of statistics and SLOSH physics).
#'
#' @param txt_dir Folder written by \code{\link{slosh_convert}}.
#' @param gauge \code{list(lat = , lon = )} of the reference gauge.
#' @param targets Data frame with \code{target} (a name), \code{lat},
#'   \code{lon}.
#' @param radius_km Search radius around each point.
#' @param storms Optional storm folders; default all.
#' @return A list of class \code{slosh_transfer} with \code{table} (one row
#'   per storm and target: \code{gauge_peak_m}, \code{target_peak_m},
#'   \code{ratio}) and \code{summary} (per target: \code{n_storms},
#'   \code{median_ratio}, \code{q25}, \code{q75}, \code{min_ratio},
#'   \code{max_ratio}).
#' @examples
#' tg <- data.frame(target = c("Bay head", "Open coast"),
#'                  lat = c(29.36, 29.26), lon = c(-94.86, -94.74))
#' slosh_transfer(slosh_example_dir(), gauge = list(lat = 29.31, lon = -94.79),
#'                targets = tg)
#' @export
slosh_transfer <- function(txt_dir, gauge, targets, radius_km = 3,
                           storms = NULL) {
  check_cols(targets, c("target", "lat", "lon"), "targets")
  if (is.null(storms)) storms <- slosh_list_storms(txt_dir)$storm
  tg <- as.data.table(targets)
  peak_at <- function(env, la, lo) {
    cc <- slosh_site_cells(env, la, lo, radius_km)$cell
    if (!length(cc)) return(NA_real_)
    safe_max(env[cell %in% cc, max_surge_m])
  }
  tab <- rbindlist(lapply(storms, function(s) {
    env <- slosh_envelope(slosh_read_frames(s, txt_dir))
    g <- peak_at(env, gauge$lat, gauge$lon)
    if (is.na(g) || g <= 0) return(NULL)
    data.table(storm = s, target = tg$target, gauge_peak_m = g,
               target_peak_m = vapply(seq_len(nrow(tg)), function(k)
                 peak_at(env, tg$lat[k], tg$lon[k]), numeric(1)))
  }))
  if (!nrow(tab)) stop("No storm covers the gauge.", call. = FALSE)
  tab[, ratio := target_peak_m / gauge_peak_m]
  summ <- tab[!is.na(ratio), .(n_storms = .N,
                               median_ratio = stats::median(ratio),
                               q25 = stats::quantile(ratio, 0.25),
                               q75 = stats::quantile(ratio, 0.75),
                               min_ratio = min(ratio),
                               max_ratio = max(ratio)), by = target]
  structure(list(table = tab[], summary = summ[]), class = "slosh_transfer")
}

#' @export
print.slosh_transfer <- function(x, ...) {
  cat("Target-to-gauge peak surge ratios\n")
  print(x$summary)
  invisible(x)
}
