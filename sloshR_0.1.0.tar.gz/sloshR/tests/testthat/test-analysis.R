d  <- slosh_example_dir()
fr <- slosh_read_frames("2099Demo_tst", d)
ts <- slosh_site_series(fr, 29.31, -94.79)

test_that("storm metrics are consistent with the series", {
  m <- slosh_storm_metrics(ts, thresholds = c(0.5, 1))
  expect_equal(m$peak_m, max(ts$surge_m, na.rm = TRUE))
  expect_equal(m$step_h, 0.5)
  expect_gte(m$hours_above_0.5m, m$hours_above_1m)
  expect_gt(m$max_rise_m_per_h, 0)
})

test_that("footprint area shrinks as the threshold rises", {
  fp <- slosh_footprint(slosh_envelope(fr), c(0.5, 1, 2, 3))
  expect_true(all(diff(fp$area_km2) <= 0))
})

test_that("tide timing finds the nearest high water", {
  t0 <- min(ts$time) - 86400
  tide <- data.frame(time = t0 + seq(0, 3 * 86400, by = 600))
  tide$level <- 0.4 * cos(2 * pi * as.numeric(tide$time - t0) / (12.42 * 3600))
  tt <- slosh_tide_timing(ts, tide)
  expect_lte(abs(tt$lag_to_high_tide_h), 6.3)
  expect_equal(tt$total_at_peak_m, tt$peak_m + tt$tide_at_peak_m)
  far <- data.frame(time = t0 - 30 * 86400 + seq(0, 86400, by = 600))
  far$level <- 0.4 * cos(as.numeric(far$time) / 7000)
  expect_true(is.na(slosh_tide_timing(ts, far)$lag_to_high_tide_h))
})

test_that("driver lag measures hours from surge peak to driver peak", {
  pk <- ts$time[which.max(ts$surge_m)]
  rain <- data.frame(time = pk + seq(-48, 48) * 3600,
                     value = exp(-((seq(-48, 48) - 10) / 6)^2))
  expect_equal(slosh_driver_lag(ts, rain)$lag_h, 10)
})

test_that("validation scores match hand calculation", {
  ev <- slosh_events(d, 29.31, -94.79, verbose = FALSE)
  obs <- data.frame(storm = ev$storm, obs_peak_m = ev$peak_surge_m + c(0.2, -0.1))
  v <- slosh_validate(ev, obs)
  expect_s3_class(v, "slosh_validation")
  expect_equal(v$summary$bias_m, mean(c(-0.2, 0.1)))
  expect_equal(v$summary$rmse_m, sqrt(mean(c(0.04, 0.01))))
  expect_output(print(v), "bias")
})

test_that("transfer ratios are target over gauge", {
  tg <- data.frame(target = "Same point", lat = 29.31, lon = -94.79)
  tr <- slosh_transfer(d, list(lat = 29.31, lon = -94.79), tg)
  expect_equal(tr$summary$median_ratio, 1)
  expect_equal(tr$summary$n_storms, 2L)
})
