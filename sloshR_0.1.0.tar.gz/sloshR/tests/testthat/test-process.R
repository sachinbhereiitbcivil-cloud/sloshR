d <- slosh_example_dir()
fr <- slosh_read_frames("2099Demo_tst", d)

test_that("envelope is the per-cell maximum", {
  env <- slosh_envelope(fr)
  expect_equal(nrow(env), 625)
  chk <- fr[, .(m = if (all(is.na(surge_ft))) NA_real_ else max(surge_ft, na.rm = TRUE)), by = cell]
  expect_equal(env$max_surge_ft, chk$m)
  expect_true(all(env$cell_km > 0))
})

test_that("site cells and series respect the radius", {
  cc <- slosh_site_cells(fr, 29.31, -94.79, radius_km = 3)
  expect_true(all(cc$dist_km <= 3))
  expect_equal(nrow(slosh_site_cells(fr, 10, 10, 3)), 0)
  ts <- slosh_site_series(fr, 29.31, -94.79)
  expect_equal(nrow(ts), 18)
  expect_equal(nrow(slosh_site_series(fr, 10, 10)), 0)
})

test_that("event table covers both storms and flags duplicates", {
  out <- file.path(tempdir(), "ev")
  ev <- slosh_events(d, 29.31, -94.79, save_dir = out, site_name = "Demo",
                     verbose = FALSE)
  expect_equal(nrow(ev), 2)
  expect_true(all(ev$covers_site))
  expect_false(any(ev$duplicate_event))
  expect_equal(attr(ev$peak_time_utc, "tzone"), "UTC")
  expect_true(file.exists(file.path(out, "slosh_events_Demo.csv")))
  far <- slosh_events(d, 10, 10, verbose = FALSE)
  expect_false(any(far$covers_site))
  expect_true(all(is.na(far$peak_surge_m)))
})
