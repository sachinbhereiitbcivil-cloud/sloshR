d  <- slosh_example_dir()
fr <- slosh_read_frames("2099Demo_tst", d)
ev <- slosh_events(d, 29.31, -94.79, verbose = FALSE)

test_that("plot functions return ggplot objects that build", {
  site <- list(name = "Demo", lat = 29.31, lon = -94.79)
  ps <- list(
    slosh_plot_peaks(ev, "Demo"),
    slosh_plot_series(slosh_site_series(fr, 29.31, -94.79), "Demo"),
    slosh_plot_map(slosh_envelope(fr), slosh_read_track("2099Demo_tst", d), site),
    slosh_plot_grids(ev))
  for (p in ps) {
    expect_s3_class(p, "ggplot")
    expect_silent(ggplot2::ggplot_build(p))
  }
})

test_that("animation writes frames (or a GIF when gifski is available)", {
  skip_on_cran()
  f <- file.path(tempdir(), "anim.gif")
  out <- suppressMessages(slosh_animate("2099Demo_tst", d, file = f,
                                        every_nth = 6, width = 300,
                                        height = 280, keep_frames = TRUE))
  expect_true(file.exists(out))
})
