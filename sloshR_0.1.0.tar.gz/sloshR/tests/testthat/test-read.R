d <- slosh_example_dir()

test_that("log and storm list are read", {
  log <- slosh_read_log(d)
  expect_equal(nrow(log), 2)
  expect_true(all(log$status == "ok"))
  st <- slosh_list_storms(d)
  expect_setequal(st$storm, c("2098Sample_tst", "2099Demo_tst"))
  expect_equal(st$n_frames, c(18L, 18L))
})

test_that("frames have the documented columns, UTC times and dry flags", {
  fr <- slosh_read_frames("2099Demo_tst", d)
  expect_named(fr, c("storm", "frame", "time", "cell", "lon", "lat",
                     "surge_ft", "surge_m"))
  expect_equal(attr(fr$time, "tzone"), "UTC")
  expect_true(any(is.na(fr$surge_ft)))           # 99.9 became NA
  expect_true(all(abs(fr$surge_ft) < 99, na.rm = TRUE))
  expect_equal(fr$surge_m, fr$surge_ft * 0.3048)
  expect_equal(nrow(slosh_read_frames("2099Demo_tst", d, frames = 0:1)),
               2 * 625)
})

test_that("track is read from .wnd files", {
  tr <- slosh_read_track("2099Demo_tst", d)
  expect_equal(nrow(tr), 18)
  expect_true(all(c("lat", "lon", "rmax_mi", "vmax_mph_10min") %in% names(tr)))
  expect_false(anyNA(tr$lat))
})

test_that("storm names are parsed with and without a storm name", {
  p <- sloshR:::parse_storm_name(c("2008Ike_gl2", "1900gl2", "1900gls-asof1900"))
  expect_equal(p$year, c(2008L, 1900L, 1900L))
  expect_equal(p$name, c("Ike", NA, NA))
  expect_equal(p$basin, c("gl2", "gl2", "gls-asof1900"))
})

test_that("conversion refuses non-Windows platforms clearly", {
  skip_on_os("windows")
  expect_error(slosh_convert(tempdir()), "Windows")
})
