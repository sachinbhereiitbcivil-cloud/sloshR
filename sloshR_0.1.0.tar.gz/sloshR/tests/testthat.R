library(testthat)
library(sloshR)
test_check("sloshR")
