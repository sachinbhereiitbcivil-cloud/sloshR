# sloshR 0.1.0 (2024-12-22)

* First release: batch conversion of SLOSH rex files, readers, envelopes,
  site series, event tables, storm metrics, flood footprints, tide and driver
  timing, validation, site-to-gauge transfer, plots and animation.
* Synthetic example data and a getting-started vignette.
