# sloshR

<!-- badges: start -->
[![R-CMD-check](https://github.com/sachinbhereiitbcivil-cloud/sloshR/actions/workflows/R-CMD-check.yaml/badge.svg)](https://github.com/sachinbhereiitbcivil-cloud/sloshR/actions/workflows/R-CMD-check.yaml)
[![License: Apache 2.0](https://img.shields.io/badge/License-Apache_2.0-blue.svg)](LICENSE.md)
<!-- badges: end -->

Read, analyse and visualise **SLOSH** storm surge model runs in R.

sloshR converts NOAA SLOSH rex files (historical and hypothetical storm runs)
to text in batch, then gives you per-storm surge envelopes, site time series,
event tables, storm metrics, flood footprints, timing against tides and
rainfall, validation statistics, site-to-gauge transfer ratios, maps and
animations.

## Installation

From GitHub:

```r
# install.packages("remotes")
remotes::install_github("sachinbhereiitbcivil-cloud/sloshR", build_vignettes = TRUE)
```

Or from the release file:

```r
install.packages(c("data.table", "ggplot2", "scales", "gifski"))
install.packages("sloshR_0.1.0.tar.gz", repos = NULL, type = "source")
```

Converting rex files (`slosh_convert()`) needs Windows and NOAA's
[SLOSH Display Program](https://slosh.nws.noaa.gov/sdp/) with rex files
installed. Every other function runs on any platform.

## Quick start

```r
library(sloshR)

# 1. Convert all rex files (Windows, once)
slosh_convert("C:/slosh.pkg/sloshdsp")
txt <- "C:/slosh.pkg/sloshdsp/output/rex_txt"

# 2. Event table at a site
ev <- slosh_events(txt, lat = 29.310, lon = -94.793, site_name = "Galveston",
                   save_dir = "slosh_results")
slosh_plot_peaks(ev, "Galveston")
slosh_plot_grids(ev)

# 3. One storm in detail
fr  <- slosh_read_frames("2008Ike_gl2", txt)
env <- slosh_envelope(fr)
slosh_plot_map(env, slosh_read_track("2008Ike_gl2", txt),
               site = list(name = "Galveston", lat = 29.310, lon = -94.793))
slosh_footprint(env, c(1, 2, 3))
slosh_animate("2008Ike_gl2", txt, site = list(name = "Galveston",
              lat = 29.310, lon = -94.793))
```

Try everything without SLOSH installed using the synthetic example data:
`slosh_example_dir()`, and see `vignette("sloshR")`.

## Functions

| Stage | Functions |
|---|---|
| Import | `slosh_convert()`, `slosh_read_log()`, `slosh_list_storms()`, `slosh_read_frames()`, `slosh_read_track()` |
| Process | `slosh_envelope()`, `slosh_site_cells()`, `slosh_site_series()`, `slosh_events()` |
| Metrics | `slosh_storm_metrics()`, `slosh_footprint()` |
| Compound timing | `slosh_tide_timing()`, `slosh_driver_lag()` |
| Validation and transfer | `slosh_validate()`, `slosh_transfer()` |
| Figures | `slosh_plot_peaks()`, `slosh_plot_series()`, `slosh_plot_map()`, `slosh_plot_grids()`, `slosh_animate()` |

## Appropriate use

SLOSH output is intended for hurricane planning and preparedness; NOAA advises
that it should not be used for engineering analysis. The NOAA rex library has
only a few storms per basin (6 unique storms at Galveston), too few on their own
for extreme-value or trend analysis.

## License and credit

Apache License 2.0. sloshR calls, but does not include, NOAA's SLOSH Display
Program and its `halo` library (Copyright 1998-2026 National Weather Service,
Apache 2.0). See `inst/NOTICE`.

SLOSH: Jelesnianski, C. P., Chen, J. and Shaffer, W. A. (1992). *SLOSH: Sea,
Lake, and Overland Surges from Hurricanes.* NOAA Technical Report NWS 48.

Cite sloshR with `citation("sloshR")` or the "Cite this repository" button on
GitHub. Contributions are welcome: see [CONTRIBUTING.md](CONTRIBUTING.md).
