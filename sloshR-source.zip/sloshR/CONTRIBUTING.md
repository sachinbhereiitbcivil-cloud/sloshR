# Contributing to sloshR

Thanks for helping improve sloshR.

- **Bugs and questions:** open an issue with a small reproducible example.
  Use `slosh_example_dir()` where possible so others can run it without SLOSH.
- **Code changes:** fork the repository, make your change on a branch, add or
  update tests in `tests/testthat/`, update the roxygen comments, then run
  `roxygen2::roxygenise()` and `R CMD check` before opening a pull request.
- **Style:** `data.table` for tables, `ggplot2` for figures, times in UTC,
  heights in metres alongside the original feet.
- **SLOSH data:** do not commit NOAA rex files or converted output; users
  download them from NOAA.

By contributing you agree that your contributions are licensed under the
Apache License 2.0.
