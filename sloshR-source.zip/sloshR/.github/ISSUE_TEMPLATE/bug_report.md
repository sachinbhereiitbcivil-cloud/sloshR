---
name: Bug report
about: Something in sloshR does not work as documented
labels: bug
---

**What happened**
A short description, and the error message if there is one.

**Code to reproduce**
```r
library(sloshR)
# smallest code that shows the problem; use slosh_example_dir() if you can
```

**Storm and basin** (if it involves real SLOSH data)
e.g. `2008Ike_gl2`, SLOSH Display Program version.

**Session info**
Paste the output of `sessionInfo()`.
